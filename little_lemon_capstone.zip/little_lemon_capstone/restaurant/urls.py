from django.urls import include, path
from rest_framework.routers import DefaultRouter
from .views import BookingViewSet, HomeView, MenuItemViewSet, RegistrationView

router = DefaultRouter()
router.register("menu", MenuItemViewSet, basename="menu")
router.register("bookings", BookingViewSet, basename="booking")

urlpatterns = [
    path("", HomeView.as_view(), name="api-home"),
    path("registration/", RegistrationView.as_view(), name="registration"),
    path("", include(router.urls)),
]
