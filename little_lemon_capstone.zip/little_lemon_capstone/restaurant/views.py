from rest_framework import generics, permissions, viewsets
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import Booking, MenuItem
from .permissions import IsStaffOrReadOnly
from .serializers import BookingSerializer, MenuItemSerializer, RegistrationSerializer


class MenuItemViewSet(viewsets.ModelViewSet):
    queryset = MenuItem.objects.all()
    serializer_class = MenuItemSerializer
    permission_classes = [IsStaffOrReadOnly]


class BookingViewSet(viewsets.ModelViewSet):
    queryset = Booking.objects.select_related("user").all()
    serializer_class = BookingSerializer
    permission_classes = [permissions.IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)


class RegistrationView(generics.CreateAPIView):
    serializer_class = RegistrationSerializer
    permission_classes = [permissions.AllowAny]


class HomeView(APIView):
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        return Response({
            "message": "Welcome to the Little Lemon API",
            "endpoints": {
                "menu": "/api/menu/",
                "bookings": "/api/bookings/",
                "registration": "/api/registration/",
                "token": "/auth/token/login/",
                "users": "/auth/users/",
            },
        })
