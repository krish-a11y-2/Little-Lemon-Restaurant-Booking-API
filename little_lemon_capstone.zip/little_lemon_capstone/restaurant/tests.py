from datetime import timedelta
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.utils import timezone
from rest_framework.test import APIClient
from .models import Booking, MenuItem

User = get_user_model()


class RestaurantModelTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.menu_item = MenuItem.objects.create(
            title="Greek Salad", price="12.50", inventory=20
        )
        cls.user = User.objects.create_user(username="testuser", password="StrongPass123!")

    def test_menu_item_string_representation(self):
        self.assertEqual(str(self.menu_item), "Greek Salad")

    def test_booking_can_be_created(self):
        booking = Booking.objects.create(
            name="Test Guest",
            no_of_guests=2,
            booking_date=timezone.now() + timedelta(days=1),
            user=self.user,
        )
        self.assertEqual(booking.no_of_guests, 2)


class RestaurantAPITests(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.user = User.objects.create_user(username="apiuser", password="StrongPass123!")

    def test_menu_list_is_public(self):
        response = self.client.get("/api/menu/")
        self.assertEqual(response.status_code, 200)

    def test_registration_endpoint_creates_user(self):
        response = self.client.post(
            "/api/registration/",
            {"username": "newuser", "email": "new@example.com", "password": "StrongPass123!"},
            format="json",
        )
        self.assertEqual(response.status_code, 201)
        self.assertTrue(User.objects.filter(username="newuser").exists())

    def test_booking_endpoint_requires_authentication(self):
        response = self.client.get("/api/bookings/")
        self.assertEqual(response.status_code, 401)

    def test_authenticated_user_can_list_bookings(self):
        self.client.force_authenticate(user=self.user)
        response = self.client.get("/api/bookings/")
        self.assertEqual(response.status_code, 200)
