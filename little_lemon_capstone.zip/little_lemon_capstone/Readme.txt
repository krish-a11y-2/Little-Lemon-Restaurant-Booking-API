LITTLE LEMON RESTAURANT BOOKING API
===================================

Requirements
------------
- Python 3.10+
- Django and Django REST Framework (see requirements.txt)
- MySQL for the database requirement (SQLite is enabled by default for quick local testing)
- Insomnia for API testing

Install
-------
1. Create and activate a virtual environment.
   Windows:
     py -m venv .venv
     .venv\Scripts\activate

2. Install dependencies:
     pip install -r requirements.txt

3. (Optional) Configure MySQL:
   Copy .env.example to .env and set DB_ENGINE=mysql, DB_NAME, DB_USER,
   DB_PASSWORD, DB_HOST, and DB_PORT. This project does not automatically
   load .env files; set those environment variables in your terminal or IDE.
   On Windows, PyMySQL is used as the MySQL driver.

4. Apply migrations and create an admin user:
     python manage.py makemigrations restaurant
     python manage.py migrate
     python manage.py createsuperuser

5. Start the server:
     python manage.py runserver

6. Run unit tests:
     python manage.py test

API endpoints
-------------
GET    /api/                         API welcome response
GET    /api/menu/                    List menu items (public)
GET    /api/menu/<id>/               Retrieve a menu item (public)
POST   /api/menu/                    Create menu item (staff user required)
PUT    /api/menu/<id>/               Update menu item (staff user required)
DELETE /api/menu/<id>/               Delete menu item (staff user required)
GET    /api/bookings/                List bookings (authentication required)
POST   /api/bookings/                Create booking (authentication required)
GET    /api/bookings/<id>/            Retrieve booking (authentication required)
PUT/PATCH/DELETE /api/bookings/<id>/ Manage booking (authentication required)
POST   /api/registration/             Register a user
POST   /auth/token/login/             Obtain a token with username/password
POST   /auth/token/logout/            Destroy the current token
POST   /api/api-token-auth/           Standard DRF token endpoint
GET/POST /auth/users/                 Djoser user endpoint

Authentication with Insomnia
-----------------------------
1. Register a user by POSTing JSON to /api/registration/:
   {"username":"demo","email":"demo@example.com","password":"StrongPass123!"}
2. Obtain a token by POSTing JSON to /auth/token/login/:
   {"username":"demo","password":"StrongPass123!"}
3. In Insomnia, choose Auth > Bearer Token and paste the token.
4. Send requests to /api/bookings/.

Notes
-----
- Menu writes require a staff user. Create a superuser with createsuperuser.
- Booking endpoints require token or session authentication.
- The MySQL database must exist before running migrations when DB_ENGINE=mysql.
- The app exposes a small HTML landing page at / when served by the project web server
  only if a root route is configured. The primary assignment APIs are under /api/.
